# Mi Sitio Web con GitHub Pages

Este es un ejemplo simple de una página web estática publicada usando **GitHub Pages**.

## 📂 Archivos

- `index.html`: Contenido principal del sitio.
- `LICENSE`: Licencia MIT para permitir su libre uso.
- `README.md`: Esta descripción del proyecto.

## 🌐 Enlace

El sitio está publicado en:  
[https://tusuario.github.io/mi-sitio-web/](https://tusuario.github.io/mi-sitio-web/)

> Reemplaza `tusuario` con tu nombre de usuario real de GitHub.

## ✍️ Autor

Creado por [Tu Nombre] – junio 2024
